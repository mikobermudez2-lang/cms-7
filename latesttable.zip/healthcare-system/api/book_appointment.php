<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/init.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$name       = trim($_POST['name'] ?? '');
$age        = (int) ($_POST['age'] ?? 0);
$email      = trim($_POST['email'] ?? '');
$phone      = trim($_POST['phone'] ?? '');
$doctorId   = (int) ($_POST['doctor_id'] ?? 0);
$date       = $_POST['date'] ?? '';
$time       = $_POST['time'] ?? '';

if (!$name || !$age || !$email || !$phone || !$doctorId || !$date || !$time) {
    echo json_encode(['success' => false, 'message' => 'All fields are required.']);
    exit;
}

try {
    $db = get_db();
    $db->beginTransaction();

    $doctorCheck = $db->prepare('SELECT COUNT(*) FROM doctors WHERE id = ?');
    $doctorCheck->execute([$doctorId]);
    if (!$doctorCheck->fetchColumn()) {
        throw new RuntimeException('Doctor not found.');
    }

    $stmt = $db->prepare('SELECT id FROM patients WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $patientId = $stmt->fetchColumn();

    if ($patientId) {
        $update = $db->prepare('UPDATE patients SET name = ?, age = ?, phone = ? WHERE id = ?');
        $update->execute([$name, $age, $phone, $patientId]);
    } else {
        $insert = $db->prepare('INSERT INTO patients (name, age, email, phone) VALUES (?, ?, ?, ?)');
        $insert->execute([$name, $age, $email, $phone]);
        $patientId = (int) $db->lastInsertId();
    }

    $appointment = $db->prepare(
        'INSERT INTO appointments (patient_id, doctor_id, date, time, status) VALUES (?, ?, ?, ?, ?)'
    );
    $appointment->execute([$patientId, $doctorId, $date, $time, 'Waiting']);

    $db->commit();

    echo json_encode(['success' => true]);
} catch (Throwable $th) {
    if (isset($db) && $db->inTransaction()) {
        $db->rollBack();
    }
    $isDoctorError = $th->getMessage() === 'Doctor not found.';
    http_response_code($isDoctorError ? 422 : 500);
    $message = $isDoctorError ? $th->getMessage() : 'Unable to save appointment.';
    echo json_encode(['success' => false, 'message' => $message]);
}


