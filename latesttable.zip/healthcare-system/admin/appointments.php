<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/init.php';
require_admin();

$db = get_db();
$flashError = null;
$statuses = ['Waiting', 'Confirmed', 'Completed', 'Rejected', 'Cancelled'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf'] ?? '')) {
        $flashError = 'Invalid session.';
    } else {
        $appointmentId = isset($_POST['id']) ? (int) $_POST['id'] : null;
        $patientId = (int) ($_POST['patient_id'] ?? 0);
        $doctorId = (int) ($_POST['doctor_id'] ?? 0);
        $date = $_POST['date'] ?? '';
        $time = $_POST['time'] ?? '';
        $status = $_POST['status'] ?? 'Waiting';

        if ($patientId && $doctorId && $date && $time && in_array($status, $statuses, true)) {
            if ($appointmentId) {
                $stmt = $db->prepare(
                    'UPDATE appointments SET patient_id = ?, doctor_id = ?, date = ?, time = ?, status = ? WHERE id = ?'
                );
                $stmt->execute([$patientId, $doctorId, $date, $time, $status, $appointmentId]);
                set_flash('Appointment updated.');
            } else {
                $stmt = $db->prepare(
                    'INSERT INTO appointments (patient_id, doctor_id, date, time, status) VALUES (?, ?, ?, ?, ?)'
                );
                $stmt->execute([$patientId, $doctorId, $date, $time, $status]);
                set_flash('Appointment created.');
            }
            redirect('/admin/appointments.php');
        } else {
            $flashError = 'All fields are required.';
        }
    }
}

if (isset($_GET['delete'])) {
    $stmt = $db->prepare('DELETE FROM appointments WHERE id = ?');
    $stmt->execute([(int) $_GET['delete']]);
    set_flash('Appointment removed.');
    redirect('/admin/appointments.php');
}

$filterStatus = $_GET['status'] ?? '';
$filterDate = $_GET['date'] ?? '';

$query = 'SELECT a.*, p.name AS patient_name, d.name AS doctor_name
          FROM appointments a
          JOIN patients p ON p.id = a.patient_id
          JOIN doctors d ON d.id = a.doctor_id';
$conditions = [];
$params = [];

if ($filterStatus) {
    $conditions[] = 'a.status = ?';
    $params[] = $filterStatus;
}
if ($filterDate) {
    $conditions[] = 'a.date = ?';
    $params[] = $filterDate;
}
if ($conditions) {
    $query .= ' WHERE ' . implode(' AND ', $conditions);
}
$query .= ' ORDER BY a.date DESC, a.time DESC';

$stmt = $db->prepare($query);
$stmt->execute($params);
$appointments = $stmt->fetchAll();

$editAppointment = null;
if (isset($_GET['edit'])) {
    $editStmt = $db->prepare('SELECT * FROM appointments WHERE id = ? LIMIT 1');
    $editStmt->execute([(int) $_GET['edit']]);
    $editAppointment = $editStmt->fetch();
}

$patients = fetch_patients();
$doctors = fetch_doctors();

$pageTitle = 'Manage Appointments';
$activePage = 'appointments';
include __DIR__ . '/partials/header.php';
$flash = get_flash();
?>
<?php if ($flash): ?>
    <div class="alert alert-<?= e($flash['type']); ?>" data-flash><?= e($flash['message']); ?></div>
<?php endif; ?>
<?php if ($flashError): ?>
    <div class="alert alert-danger"><?= e($flashError); ?></div>
<?php endif; ?>

<div class="row g-4">
    <div class="col-lg-8">
        <div class="card card-shadow mb-4">
            <div class="card-header bg-white border-0">
                <form class="row g-2 align-items-end" method="get">
                    <div class="col-md-4">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select">
                            <option value="">All</option>
                            <?php foreach ($statuses as $status): ?>
                                <option value="<?= e($status); ?>" <?= $filterStatus === $status ? 'selected' : ''; ?>><?= e($status); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Date</label>
                        <input type="date" name="date" value="<?= e($filterDate); ?>" class="form-control">
                    </div>
                    <div class="col-md-4 d-flex gap-2">
                        <button class="btn btn-primary mt-auto" type="submit">Filter</button>
                        <a href="/admin/appointments.php" class="btn btn-outline-secondary mt-auto">Reset</a>
                    </div>
                </form>
            </div>
        </div>
        <div class="card card-shadow">
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Patient</th>
                            <th>Doctor</th>
                            <th>Status</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($appointments as $appt): ?>
                            <tr>
                                <td><?= e(date('M d, Y', strtotime($appt['date']))); ?></td>
                                <td><?= e(date('h:i A', strtotime($appt['time']))); ?></td>
                                <td><?= e($appt['patient_name']); ?></td>
                                <td><?= e($appt['doctor_name']); ?></td>
                                <td>
                                    <span class="badge text-bg-<?= $appt['status'] === 'Waiting' ? 'warning' : ($appt['status'] === 'Confirmed' ? 'success' : 'secondary'); ?>">
                                        <?= e($appt['status']); ?>
                                    </span>
                                </td>
                                <td class="text-end">
                                    <a class="btn btn-sm btn-primary" href="/admin/appointments.php?edit=<?= (int) $appt['id']; ?>">Edit</a>
                                    <a class="btn btn-sm btn-outline-danger" href="/admin/appointments.php?delete=<?= (int) $appt['id']; ?>" onclick="return confirm('Delete appointment?');">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($appointments)): ?>
                            <tr><td colspan="6" class="text-center text-muted">No appointments found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-section">
            <h5 class="mb-3"><?= $editAppointment ? 'Edit Appointment' : 'Add Appointment'; ?></h5>
            <form method="post">
                <input type="hidden" name="csrf" value="<?= e(csrf_token()); ?>">
                <?php if ($editAppointment): ?>
                    <input type="hidden" name="id" value="<?= (int) $editAppointment['id']; ?>">
                <?php endif; ?>
                <div class="mb-3">
                    <label class="form-label">Patient</label>
                    <select name="patient_id" class="form-select" required>
                        <option value="">Select patient</option>
                        <?php foreach ($patients as $patient): ?>
                            <option value="<?= (int) $patient['id']; ?>" <?= isset($editAppointment['patient_id']) && $editAppointment['patient_id'] == $patient['id'] ? 'selected' : ''; ?>>
                                <?= e($patient['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Doctor</label>
                    <select name="doctor_id" class="form-select" required>
                        <option value="">Select doctor</option>
                        <?php foreach ($doctors as $doctor): ?>
                            <option value="<?= (int) $doctor['id']; ?>" <?= isset($editAppointment['doctor_id']) && $editAppointment['doctor_id'] == $doctor['id'] ? 'selected' : ''; ?>>
                                <?= e($doctor['name']); ?> — <?= e($doctor['specialty']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Date</label>
                    <input type="date" name="date" class="form-control" required value="<?= e($editAppointment['date'] ?? ''); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Time</label>
                    <input type="time" name="time" class="form-control" required value="<?= e($editAppointment['time'] ?? ''); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <?php foreach ($statuses as $status): ?>
                            <option value="<?= e($status); ?>" <?= (isset($editAppointment['status']) ? $editAppointment['status'] : 'Waiting') === $status ? 'selected' : ''; ?>>
                                <?= e($status); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="d-grid gap-2">
                    <button class="btn btn-primary" type="submit"><?= $editAppointment ? 'Update' : 'Add'; ?> Appointment</button>
                    <?php if ($editAppointment): ?>
                        <a class="btn btn-outline-secondary" href="/admin/appointments.php">Cancel</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>

