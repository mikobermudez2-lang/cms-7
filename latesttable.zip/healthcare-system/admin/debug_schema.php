<?php
require_once __DIR__ . '/../includes/init.php';
require_admin_or_staff();

$db = get_db();

echo "<h1>Database Schema Debug</h1>";

// Check Categories Table
echo "<h2>Categories Table Columns:</h2>";
try {
    $stmt = $db->query("SHOW COLUMNS FROM categories");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "<ul>";
    $hasArchivedAt = false;
    foreach ($columns as $col) {
        echo "<li>" . htmlspecialchars($col['Field']) . " (" . htmlspecialchars($col['Type']) . ")</li>";
        if ($col['Field'] === 'archived_at') {
            $hasArchivedAt = true;
        }
    }
    echo "</ul>";
    
    if ($hasArchivedAt) {
        echo "<p style='color: green; font-weight: bold;'>✅ 'archived_at' column exists in categories table.</p>";
    } else {
        echo "<p style='color: red; font-weight: bold;'>❌ 'archived_at' column MISSING in categories table.</p>";
    }
} catch (Exception $e) {
    echo "<p style='color: red;'>Error checking categories: " . $e->getMessage() . "</p>";
}

// Check Posts Table
echo "<h2>Posts Table Columns:</h2>";
try {
    $stmt = $db->query("SHOW COLUMNS FROM posts");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "<ul>";
    $hasArchivedAt = false;
    foreach ($columns as $col) {
        echo "<li>" . htmlspecialchars($col['Field']) . " (" . htmlspecialchars($col['Type']) . ")</li>";
        if ($col['Field'] === 'archived_at') {
            $hasArchivedAt = true;
        }
    }
    echo "</ul>";
    
    if ($hasArchivedAt) {
        echo "<p style='color: green; font-weight: bold;'>✅ 'archived_at' column exists in posts table.</p>";
    } else {
        echo "<p style='color: red; font-weight: bold;'>❌ 'archived_at' column MISSING in posts table.</p>";
    }
} catch (Exception $e) {
    echo "<p style='color: red;'>Error checking posts: " . $e->getMessage() . "</p>";
}
