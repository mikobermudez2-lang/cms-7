-- Add archive functionality to categories table
-- This allows soft-delete instead of permanent deletion

USE healthcare_db;

-- Add archived_at column to categories table
ALTER TABLE categories 
ADD COLUMN archived_at DATETIME DEFAULT NULL AFTER created_at,
ADD INDEX idx_archived_at (archived_at);

-- Verify the change
SHOW COLUMNS FROM categories;
