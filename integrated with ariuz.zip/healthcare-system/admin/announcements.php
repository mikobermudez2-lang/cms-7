<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/init.php';
require_admin();

$db = get_db();
$flashError = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf'] ?? '')) {
        $flashError = 'Invalid session.';
    } else {
        $message = trim($_POST['message'] ?? '');
        if ($message) {
            $stmt = $db->prepare('INSERT INTO announcements (message) VALUES (?)');
            $stmt->execute([$message]);
            set_flash('Announcement posted.');
            redirect('/admin/announcements.php');
        } else {
            $flashError = 'Message is required.';
        }
    }
}

if (isset($_GET['delete'])) {
    $stmt = $db->prepare('DELETE FROM announcements WHERE id = ?');
    $stmt->execute([(int) $_GET['delete']]);
    set_flash('Announcement removed.');
    redirect('/admin/announcements.php');
}

$announcementsStmt = $db->query('SELECT * FROM announcements ORDER BY created_at DESC');
$announcements = $announcementsStmt->fetchAll();

$pageTitle = 'Announcements';
$activePage = 'announcements';
include __DIR__ . '/partials/header.php';
$flash = get_flash();
?>
<?php if ($flash): ?>
    <div class="alert alert-<?= e($flash['type']); ?>" data-flash><?= e($flash['message']); ?></div>
<?php endif; ?>
<?php if ($flashError): ?>
    <div class="alert alert-danger"><?= e($flashError); ?></div>
<?php endif; ?>

<div class="row g-4">
    <div class="col-lg-7">
        <?php foreach ($announcements as $announcement): ?>
            <div class="announcement-card mb-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <small class="text-muted"><?= e(date('M d, Y h:i A', strtotime($announcement['created_at']))); ?></small>
                    <a class="btn btn-sm btn-outline-danger" href="/admin/announcements.php?delete=<?= (int) $announcement['id']; ?>" onclick="return confirm('Delete announcement?');">Delete</a>
                </div>
                <p class="mb-0"><?= e($announcement['message']); ?></p>
            </div>
        <?php endforeach; ?>
        <?php if (empty($announcements)): ?>
            <p class="text-muted">No announcements posted yet.</p>
        <?php endif; ?>
    </div>
    <div class="col-lg-5">
        <div class="form-section">
            <h5 class="mb-3">Create Announcement</h5>
            <form method="post">
                <input type="hidden" name="csrf" value="<?= e(csrf_token()); ?>">
                <div class="mb-3">
                    <label class="form-label">Message</label>
                    <textarea name="message" rows="5" class="form-control" required></textarea>
                </div>
                <button class="btn btn-primary" type="submit">Publish</button>
            </form>
        </div>
    </div>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>

