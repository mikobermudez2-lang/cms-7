<?php

declare(strict_types=1);

/**
 * Global configuration for database credentials and app constants.
 */
const DB_HOST = '127.0.0.1';
const DB_NAME = 'healthcare_db';
const DB_USER = 'root';
const DB_PASS = '';

const APP_NAME = 'Blue Pulse';

// Admin email for notifications (update with your admin email)
const ADMIN_EMAIL = 'bluepulsehospital@gmail.com';

// Debug mode - set to false in production
const DEBUG_MODE = true;

// ============================================
// EXTERNAL JOBS INTEGRATION CONFIGURATION
// ============================================
// Set to true to enable external jobs integration
const EXTERNAL_JOBS_ENABLED = true;

// HR API Configuration (for jobs integration)
// For Radmin VPN testing: Use the IP address of the PC running the HR API
// Example: 'http://26.137.144.53/HR-EMPLOYEE-MANAGEMENT/API'
const HR_API_BASE = 'http://26.137.144.53/HR-EMPLOYEE-MANAGEMENT/API';
const HR_API_JOB_POSTINGS = '/get_job_postings.php';

// ============================================
// HR AUTHENTICATION INTEGRATION CONFIGURATION
// ============================================
// Set to true to enable HR system user authentication
const HR_AUTH_ENABLED = true;

// HR API endpoint for user authentication
const HR_API_AUTH_ENDPOINT = '/get_users.php';

// HR Dashboard URL - where HR users should be redirected after login
const HR_DASHBOARD_URL = 'http://26.137.144.53/HR-EMPLOYEE-MANAGEMENT/Manager_Dashboard.php';

// HR users that should redirect to external HR dashboard (instead of staying in local system)
// Add email addresses here that should redirect externally
const HR_EXTERNAL_REDIRECT_USERS = [
    'antonio_rhoannenicole@plpasig.edu.ph',
    // Add more email addresses here as needed
];

// Role mapping: HR sub_role => Healthcare system role
// HR users with role "Employee" can have various sub_roles
// Map them to appropriate system roles (admin, staff, doctor, employee)
const HR_ROLE_MAPPING = [
    'HR Manager' => 'admin',
    'Content Management Admin' => 'admin', // Fixed typo from "Manager"
    'Human Resources (HR) Admin' => 'admin',
    'Patient Management Admin' => 'admin',
    'Recruitment Management Admin' => 'admin',
    'Point of Sales Admin' => 'staff',
    'Inventory Admin' => 'staff',
    'System Staff' => 'staff',
    'Recruitment Manager' => 'staff',
    // Add more mappings as needed
];

// Default role for HR users if sub_role is not in mapping
const HR_DEFAULT_ROLE = 'employee';

// Field mapping: API field => local field
// Based on actual HR API response structure
const EXTERNAL_JOBS_FIELD_MAP = [
    'jobID' => 'external_id',        // API uses 'jobID' (case-sensitive)
    'id' => 'external_id',           // Fallback
    'job_id' => 'external_id',       // Fallback
    'job_title' => 'title',          // API uses 'job_title'
    'title' => 'title',               // Fallback
    'job_description' => 'description', // API uses 'job_description'
    'description' => 'description',   // Fallback
    'department' => 'department',     // API returns department ID (number)
    'location' => 'location',       // API may return null
    'employment_type' => 'employment_type', // API returns employment_type ID (number)
    'date_posted' => 'posted_at',    // API uses 'date_posted'
    'posted_at' => 'posted_at',      // Fallback
    'closing_date' => 'closes_at',   // API provides closing_date
    'expected_salary' => 'salary_range', // Map to salary_range if needed
    'image' => 'image_url',          // API image field
    'picture' => 'image_url',        // Fallback
    'cover' => 'image_url',          // Fallback
    // Note: API doesn't provide 'summary' or 'status' fields
];

// ============================================
// MULTI-SYSTEM LOGIN ROUTING CONFIGURATION
// ============================================
// Configure where users should be redirected based on their role or email domain

// External system URLs for role-based routing
const INVENTORY_DASHBOARD_URL = 'http://localhost/inventory-system/dashboard.php';
const SUPPLIER_PORTAL_URL = 'http://localhost/inventory-system/supplier_portal_db.php';

// Role-to-URL mapping
// When a user logs in with a specific role, redirect them to the appropriate system
const ROLE_ROUTING = [
    'employee' => INVENTORY_DASHBOARD_URL,  // Inventory/HR employees
    'supplier' => SUPPLIER_PORTAL_URL,      // Suppliers
    'admin' => null,                        // Healthcare admins stay in this system
    'staff' => null,                        // Healthcare staff stay in this system
];

// Email domain-based routing (optional)
// Redirect users based on their email domain
const DOMAIN_ROUTING = [
    // '@inventory.com' => INVENTORY_DASHBOARD_URL,
    // '@supplier.com' => SUPPLIER_PORTAL_URL,
    // Add more domain mappings as needed
];

