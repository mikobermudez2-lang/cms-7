<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';

/**
 * Authenticate a user against the HR API
 * 
 * @param string $email User's email address
 * @param string $password User's password
 * @param string $subRole Optional sub_role filter
 * @return array Response with 'success' and 'data' or 'error'
 */
function authenticate_hr_user(string $email, string $password, string $subRole = ''): array
{
    if (!HR_AUTH_ENABLED) {
        return [
            'success' => false,
            'error' => 'HR authentication is disabled'
        ];
    }

    $payload = [
        'user' => [
            'email' => $email,
            'password' => $password,
            'sub_role' => $subRole,
        ],
    ];

    $response = call_hr_api(HR_API_AUTH_ENDPOINT, $payload);

    if (!$response['success']) {
        return $response;
    }

    // Parse the HR API response
    $data = $response['data'];
    
    if (DEBUG_MODE) {
        error_log("HR API Response Data: " . json_encode($data));
    }
    
    // Check if authentication was explicitly marked as error
    if (isset($data['status']) && $data['status'] === 'error') {
        return [
            'success' => false,
            'error' => $data['message'] ?? 'Authentication failed'
        ];
    }

    // Handle different response formats from HR API
    $hrUser = null;
    
    // Format 1: Response has 'users' array
    if (isset($data['users']) && is_array($data['users']) && count($data['users']) > 0) {
        $hrUser = $data['users'][0];
    }
    // Format 2: Response is a direct user object (has email field)
    elseif (isset($data['email']) || isset($data['user_email']) || isset($data['username'])) {
        $hrUser = $data;
    }
    // Format 3: Response has 'user' object
    elseif (isset($data['user']) && is_array($data['user'])) {
        $hrUser = $data['user'];
    }
    // Format 4: Response has 'data' object with user info
    elseif (isset($data['data']) && is_array($data['data'])) {
        $hrUser = $data['data'];
    }

    // If we found user data, validate it
    if ($hrUser) {
        // Verify the user is active (if status field exists)
        if (isset($hrUser['status']) && $hrUser['status'] !== 'active' && $hrUser['status'] !== 'Active') {
            return [
                'success' => false,
                'error' => 'User account is not active'
            ];
        }

        return [
            'success' => true,
            'data' => $hrUser
        ];
    }

    // If we reach here, we couldn't parse the response or authenticate
    if (DEBUG_MODE) {
        error_log("HR API: Authentication failed - could not parse valid user data from response");
        error_log("HR API Response structure: " . json_encode($data));
    }
    
    return [
        'success' => false,
        'error' => 'Invalid credentials or user not found'
    ];
}

/**
 * Make a call to the HR API
 * 
 * @param string $endpoint API endpoint (e.g., '/get_users.php')
 * @param array $payload Data to send as JSON
 * @return array Response with 'success' and 'data' or 'error'
 */
function call_hr_api(string $endpoint, array $payload): array
{
    $url = HR_API_BASE . $endpoint;
    
    if (DEBUG_MODE) {
        error_log("HR API Call: {$url}");
        error_log("HR API Payload: " . json_encode($payload));
    }

    $jsonPayload = json_encode($payload);
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Accept: application/json'
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonPayload);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10); // 10 second timeout
    
    $response = curl_exec($ch);
    $error = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($error) {
        if (DEBUG_MODE) {
            error_log("HR API Error: {$error}");
        }
        return [
            'success' => false,
            'error' => 'Failed to connect to HR system: ' . $error
        ];
    }

    // Accept any 2xx status code as success
    if ($httpCode < 200 || $httpCode >= 300) {
        if (DEBUG_MODE) {
            error_log("HR API HTTP Code: {$httpCode}");
        }
        return [
            'success' => false,
            'error' => "HR system returned error code: {$httpCode}"
        ];
    }

    $data = json_decode($response, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        if (DEBUG_MODE) {
            error_log("HR API JSON Error: " . json_last_error_msg());
            error_log("HR API Response: {$response}");
        }
        return [
            'success' => false,
            'error' => 'Invalid response from HR system'
        ];
    }

    if (DEBUG_MODE) {
        error_log("HR API Response: " . json_encode($data));
    }

    return [
        'success' => true,
        'data' => $data
    ];
}

/**
 * Map HR sub_role to healthcare system role
 * 
 * @param string $subRole HR sub_role
 * @return string Mapped system role
 */
function map_hr_role(string $subRole): string
{
    // Check if sub_role exists in mapping
    if (isset(HR_ROLE_MAPPING[$subRole])) {
        return HR_ROLE_MAPPING[$subRole];
    }
    
    // Return default role if not found
    return HR_DEFAULT_ROLE;
}
