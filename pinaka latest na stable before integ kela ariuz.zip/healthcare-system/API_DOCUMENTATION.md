# Healthcare System API & Data Integration Documentation

## Table of Contents
1. [System Architecture Overview](#system-architecture-overview)
2. [External API Integrations](#external-api-integrations)
   - [HR API Integration](#hr-api-integration)
   - [Jobs API Integration](#jobs-api-integration)
3. [Internal API Endpoints](#internal-api-endpoints)
4. [Data Flow Diagrams](#data-flow-diagrams)
5. [Configuration](#configuration)
6. [Error Handling](#error-handling)

---

## System Architecture Overview

The Healthcare System uses a **hybrid data architecture** that combines:
- **Local Database** (`healthcare_db`) - Stores core application data
- **External HR API** - Provides user authentication and job postings
- **Internal REST APIs** - Exposes data to the frontend via JSON endpoints

```
┌─────────────────┐         ┌──────────────────┐         ┌─────────────────┐
│   Frontend      │────────▶│  Internal APIs   │────────▶│ Local Database  │
│  (JavaScript)   │◀────────│  (/api/*.php)    │◀────────│  (MySQL)        │
└─────────────────┘         └──────────────────┘         └─────────────────┘
                                     │
                                     │ cURL/HTTP
                                     ▼
                            ┌──────────────────┐
                            │   External       │
                            │   HR API         │
                            │ (Remote Server)  │
                            └──────────────────┘
```

---

## External API Integrations

### HR API Integration

#### Purpose
The HR API integration serves **two primary functions**:
1. **User Authentication** - Validates users against an external HR system
2. **Job Postings Sync** - Automatically imports job listings from HR database

#### Configuration Location
**File:** `includes/config.php`

```php
// HR API Base URL
const HR_API_BASE = 'http://26.137.144.53/HR-EMPLOYEE-MANAGEMENT/API';

// Authentication endpoint
const HR_API_AUTH_ENDPOINT = '/get_users.php';

// Job postings endpoint
const HR_API_JOB_POSTINGS = '/get_job_postings.php';

// Enable/disable integrations
const HR_AUTH_ENABLED = true;
const EXTERNAL_JOBS_ENABLED = true;
```

---

### 1. HR User Authentication Flow

#### How It Works

When a user attempts to log in, the system follows this flow:

**Step 1: Check Local Database**
```php
// File: includes/auth.php - attempt_login()
$stmt = $db->prepare('SELECT id, username, password, role FROM users WHERE username = ?');
$stmt->execute([$username]);
$user = $stmt->fetch();
```

**Step 2: If Not Found Locally, Try HR API**
```php
// File: includes/auth.php - Line 35-36
if (!$user && HR_AUTH_ENABLED) {
    return attempt_hr_login($username, $password, $ip);
}
```

**Step 3: Make API Request**
```php
// File: includes/hr_api.php - authenticate_hr_user()

// Prepare payload
$payload = [
    'user' => [
        'email' => $email,
        'password' => $password,
        'sub_role' => $subRole
    ]
];

// Send POST request with cURL
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Accept: application/json'
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
curl_setopt($ch, CURLOPT_TIMEOUT, 10);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
```

**Step 4: Parse API Response**
```php
// File: includes/hr_api.php - Lines 56-67

// The API can return different response formats:
// Format 1: { "users": [{ "email": "...", "fullname": "..." }] }
// Format 2: { "email": "...", "fullname": "..." }
// Format 3: { "user": { "email": "...", "fullname": "..." } }

if (isset($data['users']) && is_array($data['users'])) {
    $hrUser = $data['users'][0];
} elseif (isset($data['email']) || isset($data['user_email'])) {
    $hrUser = $data;
}
```

**Step 5: Sync User to Local Database**
```php
// File: includes/auth.php - sync_hr_user_to_local()

// Map HR role to system role
$systemRole = map_hr_role($subRole); // Uses HR_ROLE_MAPPING constant

// Check if user exists locally
$stmt = $db->prepare('SELECT * FROM users WHERE username = ?');
$stmt->execute([$email]);
$existingUser = $stmt->fetch();

if ($existingUser) {
    // Update existing user
    $stmt = $db->prepare('UPDATE users SET display_name = ?, role = ? WHERE id = ?');
    $stmt->execute([$fullname, $systemRole, $existingUser['id']]);
} else {
    // Create new user
    $userId = generate_id();
    $stmt = $db->prepare(
        'INSERT INTO users (id, username, email, password, role, display_name, is_active) 
         VALUES (?, ?, ?, ?, ?, ?, 1)'
    );
    $stmt->execute([$userId, $email, $email, hash_password($password), $systemRole, $fullname]);
}
```

**Step 6: Create Session**
```php
$_SESSION['user'] = [
    'id' => $localUser['id'],
    'username' => $localUser['username'],
    'role' => $localUser['role'],
    'display_name' => $localUser['display_name']
];
```

#### Role Mapping

The system maps HR sub-roles to local system roles:

```php
// File: includes/config.php - HR_ROLE_MAPPING
const HR_ROLE_MAPPING = [
    'HR Manager' => 'admin',
    'Content Management Admin' => 'admin',
    'Human Resources (HR) Admin' => 'admin',
    'Patient Management Admin' => 'admin',
    'Recruitment Management Admin' => 'admin',
    'Point of Sales Admin' => 'staff',
    'Inventory Admin' => 'staff',
    'System Staff' => 'staff',
    'Recruitment Manager' => 'staff'
];

// Default role if not in mapping
const HR_DEFAULT_ROLE = 'employee';
```

---

### 2. Jobs API Integration

#### Purpose
Automatically synchronize job postings from external HR system to the local database.

#### How Job Sync Works

**Trigger Points:**
1. **Automatic Sync** - When users visit `/public/careers.php` (every 5 minutes per session)
2. **Manual Sync** - Admin clicks "Sync External Jobs" button in admin panel

#### Automatic Sync Flow

**Step 1: Page Load Trigger**
```php
// File: public/careers.php - Lines 9-26

if (EXTERNAL_JOBS_ENABLED && function_exists('sync_external_jobs')) {
    // Only sync once every 5 minutes (300 seconds)
    if (!isset($_SESSION['last_job_sync']) || (time() - $_SESSION['last_job_sync']) > 300) {
        try {
            $syncResult = sync_external_jobs();
            $_SESSION['last_job_sync'] = time();
            
            if (!$syncResult['success']) {
                error_log('Auto-sync failed: ' . $syncResult['message']);
            }
        } catch (Throwable $e) {
            error_log('Auto-sync error: ' . $e->getMessage());
        }
    }
}
```

**Step 2: Fetch Jobs from HR API**
```php
// File: includes/jobs_integration.php - fetch_jobs_from_api()

$url = HR_API_BASE . HR_API_JOB_POSTINGS; // http://26.137.144.53/.../get_job_postings.php

$data = [
    'search' => $filters['search'] ?? '',
    'department_id' => $filters['department_id'] ?? 0,
    'employment_type_id' => $filters['employment_type_id'] ?? 0,
    'created_from' => $filters['created_from'] ?? '',
    'created_to' => $filters['created_to'] ?? ''
];

// Send POST request
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_TIMEOUT, 15);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 8);

$response = curl_exec($ch);
curl_close($ch);
```

**Step 3: Extract Jobs from Response**
```php
// File: includes/jobs_integration.php - Lines 142-156

$response = json_decode($response, true);

// Try multiple possible response structures
if (isset($response['data']) && is_array($response['data'])) {
    $externalJobs = $response['data'];
} elseif (isset($response['jobs']) && is_array($response['jobs'])) {
    $externalJobs = $response['jobs'];
} elseif (isset($response['job_postings'])) {
    $externalJobs = $response['job_postings'];
} elseif (is_array($response) && isset($response[0])) {
    // Response is directly an array of jobs
    $externalJobs = $response;
}
```

**Step 4: Filter Open Jobs Only**
```php
// File: includes/jobs_integration.php - Lines 164-176

$externalJobs = array_filter($externalJobs, function ($job) {
    $status = $job['status'] ?? $job['job_status'] ?? $job['is_open'] ?? null;
    
    if ($status !== null) {
        $statusLower = strtolower((string) $status);
        // Accept: 'open', 'active', '1', 'true'
        return in_array($statusLower, ['open', 'active', '1', 'true']) 
            || $status === true || $status === 1;
    }
    
    // If no status field, assume it's open
    return true;
});
```

**Step 5: Map External Fields to Local Fields**
```php
// File: includes/jobs_integration.php - map_external_job_fields()

// Field mapping configuration (from config.php)
const EXTERNAL_JOBS_FIELD_MAP = [
    'jobID' => 'external_id',
    'job_title' => 'title',
    'job_description' => 'description',
    'department' => 'department',
    'location' => 'location',
    'employment_type' => 'employment_type',
    'date_posted' => 'posted_at',
    'closing_date' => 'closes_at',
    'image' => 'image_url'
];

// Map fields
foreach (EXTERNAL_JOBS_FIELD_MAP as $externalField => $localField) {
    if (isset($externalJob[$externalField])) {
        $mapped[$localField] = $externalJob[$externalField];
    }
}
```

**Step 6: Download Job Images**
```php
// File: includes/jobs_integration.php - download_job_image()

if (!empty($mappedData['image_url'])) {
    $uploadDir = __DIR__ . '/../public/uploads/jobs/';
    $filename = 'job_' . $safeJobId . '.' . $extension;
    
    $ch = curl_init($url);
    $fp = fopen($localPath, 'wb');
    curl_setopt($ch, CURLOPT_FILE, $fp);
    curl_exec($ch);
    
    // Store local path
    $mappedData['image_url'] = '/public/uploads/jobs/' . $filename;
}
```

**Step 7: Insert or Update Jobs**
```php
// File: includes/jobs_integration.php - Lines 282-368

$db->beginTransaction();

// Check if job already exists
$checkStmt = $db->prepare('SELECT id FROM jobs WHERE external_id = ?');
$checkStmt->execute([$externalId]);
$existing = $checkStmt->fetch();

if ($existing) {
    // UPDATE existing job
    $updateStmt = $db->prepare(
        'UPDATE jobs SET
            title = :title,
            department = :department,
            location = :location,
            employment_type = :employment_type,
            summary = :summary,
            description = :description,
            status = :status,
            posted_at = :posted_at,
            closes_at = :closes_at,
            image_url = :image_url,
            updated_at = NOW()
        WHERE external_id = :external_id'
    );
    $updateStmt->execute($mappedData);
} else {
    // INSERT new job
    $newId = generate_id();
    $insertStmt = $db->prepare(
        'INSERT INTO jobs (
            id, external_id, title, department, location, 
            employment_type, summary, description, status, 
            posted_at, closes_at, image_url
        ) VALUES (
            :id, :external_id, :title, :department, :location,
            :employment_type, :summary, :description, :status, 
            :posted_at, :closes_at, :image_url
        )'
    );
    $insertData = array_merge(['id' => $newId], $mappedData);
    $insertStmt->execute($insertData);
}

$db->commit();
```

---

## Internal API Endpoints

The system exposes several REST API endpoints under the `/api/` directory for frontend consumption.

### 1. Doctors API
**Endpoint:** `GET /api/doctors.php`

**Purpose:** Fetch list of all doctors

**File:** `api/doctors.php`

```php
$db = get_db();
$stmt = $db->query('SELECT id, name, specialty FROM doctors ORDER BY name');
echo json_encode($stmt->fetchAll());
```

**Response:**
```json
[
    {
        "id": "DOC001",
        "name": "Dr. Sarah Johnson",
        "specialty": "Cardiology"
    },
    {
        "id": "DOC002",
        "name": "Dr. Michael Chen",
        "specialty": "Pediatrics"
    }
]
```

**Usage in Frontend:**
```javascript
// File: public/doctors.html - Line 54
fetch('/api/doctors.php')
    .then(response => response.json())
    .then(doctors => {
        // Populate doctor selection dropdown
        doctors.forEach(doctor => {
            const option = document.createElement('option');
            option.value = doctor.id;
            option.textContent = `${doctor.name} - ${doctor.specialty}`;
            doctorSelect.appendChild(option);
        });
    });
```

---

### 2. Book Appointment API
**Endpoint:** `POST /api/book_appointment.php`

**Purpose:** Create new appointment and patient record

**File:** `api/book_appointment.php`

**Request Body:**
```javascript
{
    "name": "John Doe",
    "age": 35,
    "email": "john@example.com",
    "phone": "+1234567890",
    "doctor_id": "DOC001",
    "date": "2024-12-15",
    "time": "10:00"
}
```

**Processing Flow:**
```php
// Step 1: Validate doctor exists
$doctorCheck = $db->prepare('SELECT COUNT(*) FROM doctors WHERE id = ?');
$doctorCheck->execute([$doctorId]);

// Step 2: Check if patient exists by email
$stmt = $db->prepare('SELECT id FROM patients WHERE email = ?');
$stmt->execute([$email]);
$patientId = $stmt->fetchColumn();

// Step 3: Insert or update patient
if ($patientId) {
    $update = $db->prepare('UPDATE patients SET name = ?, age = ?, phone = ? WHERE id = ?');
    $update->execute([$name, $age, $phone, $patientId]);
} else {
    $insert = $db->prepare('INSERT INTO patients (name, age, email, phone) VALUES (?, ?, ?, ?)');
    $insert->execute([$name, $age, $email, $phone]);
    $patientId = $db->lastInsertId();
}

// Step 4: Create appointment
$appointment = $db->prepare(
    'INSERT INTO appointments (patient_id, doctor_id, date, time, status) VALUES (?, ?, ?, ?, ?)'
);
$appointment->execute([$patientId, $doctorId, $date, $time, 'Waiting']);
```

**Response:**
```json
{
    "success": true
}
```

---

### 3. Search API
**Endpoint:** `GET /api/search.php?q={query}&type={posts|jobs}&page={page}`

**Purpose:** Search posts or jobs with filters

**File:** `api/search.php`

**Query Parameters:**
- `q` - Search query
- `type` - "posts" or "jobs"
- `page` - Page number (default: 1)
- `per_page` - Results per page (default: 10, max: 50)
- `category` - Filter by category (posts only)
- `department` - Filter by department (jobs only)
- `employment_type` - Filter by employment type (jobs only)
- `date_from` / `date_to` - Date range filter

**Example Request:**
```
GET /api/search.php?q=cardiology&type=posts&page=1&category=health-tips
```

**Processing Flow:**
```php
if ($type === 'jobs') {
    $results = search_jobs($query, $options, $page, $perPage);
} else {
    $results = search_posts($query, $options, $page, $perPage);
}

// Format response
$items = array_map(function ($item) use ($type) {
    if ($type === 'posts') {
        return [
            'id' => $item['id'],
            'title' => $item['title'],
            'slug' => $item['slug'],
            'excerpt' => excerpt($item['content'], 160),
            'category' => $item['category_name'],
            'published_at' => $item['published_at']
        ];
    } else {
        return [
            'id' => $item['id'],
            'title' => $item['title'],
            'department' => $item['department'],
            'employment_type' => $item['employment_type'],
            'summary' => $item['summary']
        ];
    }
}, $results['items']);
```

**Response:**
```json
{
    "success": true,
    "data": {
        "items": [...],
        "total": 45,
        "page": 1,
        "per_page": 10,
        "total_pages": 5,
        "query": "cardiology"
    }
}
```

---

### 4. Blog/Posts API
**Endpoint:** `GET /api/blog.php?category={slug}&page={page}`

**Purpose:** Fetch blog posts with pagination

**File:** `api/blog.php`

**Usage in Frontend:**
```javascript
// File: public/includes/footer.php - Line 191
const params = new URLSearchParams({
    category: currentCategory,
    page: currentPage,
    per_page: 6
});

const response = await fetch('/api/blog.php?' + params.toString());
const data = await response.json();

data.posts.forEach(post => {
    // Render post cards
});
```

---

### 5. Suggestions API (Search Autocomplete)
**Endpoint:** `GET /api/suggestions.php?q={query}`

**Purpose:** Provide search suggestions for autocomplete

**File:** `api/suggestions.php`

**Usage in Frontend:**
```javascript
// File: public/includes/header.php - Line 946
const response = await fetch('/api/suggestions.php?q=' + encodeURIComponent(query));
const suggestions = await response.json();

suggestions.forEach(suggestion => {
    // Display suggestion in dropdown
});
```

---

## Data Flow Diagrams

### User Login Flow with HR API

```
┌──────────┐
│  User    │
│ Submits  │
│  Login   │
└────┬─────┘
     │
     ▼
┌─────────────────────────────────┐
│  Check Local Database           │
│  SELECT * FROM users            │
│  WHERE username = ?             │
└────┬──────────────────┬─────────┘
     │                  │
   Found           Not Found
     │                  │
     │                  ▼
     │         ┌─────────────────────┐
     │         │ Call HR API         │
     │         │ POST /get_users.php │
     │         └────┬────────────────┘
     │              │
     │              ▼
     │         ┌─────────────────────┐
     │         │ Parse API Response  │
     │         │ Extract user data   │
     │         └────┬────────────────┘
     │              │
     │              ▼
     │         ┌─────────────────────┐
     │         │ Sync to Local DB    │
     │         │ INSERT/UPDATE users │
     │         └────┬────────────────┘
     │              │
     ├──────────────┘
     │
     ▼
┌─────────────────────┐
│ Create Session      │
│ $_SESSION['user']   │
└─────────────────────┘
```

### Job Sync Flow

```
┌──────────────────┐
│ User Visits      │
│ /careers.php     │
└────┬─────────────┘
     │
     ▼
┌─────────────────────────────────┐
│ Check Session Timestamp         │
│ Last sync > 5 minutes ago?      │
└────┬──────────────────┬─────────┘
     │ YES              │ NO
     │                  │
     │                  ▼
     │            Skip sync
     │
     ▼
┌─────────────────────────────────┐
│ Call HR API                     │
│ POST /get_job_postings.php      │
│ With filters (optional)         │
└────┬────────────────────────────┘
     │
     ▼
┌─────────────────────────────────┐
│ Parse Response                  │
│ Extract job array from various  │
│ possible response structures    │
└────┬────────────────────────────┘
     │
     ▼
┌─────────────────────────────────┐
│ Filter Open Jobs                │
│ status IN ('open','active')     │
└────┬────────────────────────────┘
     │
     ▼
┌─────────────────────────────────┐
│ For Each Job:                   │
│ 1. Map fields                   │
│ 2. Download image (if exists)   │
│ 3. Check if exists (external_id)│
└────┬────────────────────────────┘
     │
     ├─────────┬──────────┐
     │ Exists  │ New      │
     │         │          │
     ▼         ▼          │
   UPDATE    INSERT      │
     │         │          │
     └────┬────┘          │
          │               │
          ▼               │
    Commit Transaction    │
          │               │
          └───────────────┘
```

### Frontend Data Fetch Flow

```
┌──────────────────┐
│  User Action     │
│  (Page Load /    │
│   Button Click)  │
└────┬─────────────┘
     │
     ▼
┌─────────────────────────────────┐
│  JavaScript fetch()             │
│  GET /api/doctors.php           │
└────┬────────────────────────────┘
     │
     ▼
┌─────────────────────────────────┐
│  PHP API Endpoint               │
│  1. Connect to DB               │
│  2. Execute SQL Query           │
│  3. Fetch results               │
└────┬────────────────────────────┘
     │
     ▼
┌─────────────────────────────────┐
│  Return JSON Response           │
│  echo json_encode($data)        │
└────┬────────────────────────────┘
     │
     ▼
┌─────────────────────────────────┐
│  JavaScript Processes Response  │
│  .then(response => response.json())
│  .then(data => renderUI(data))  │
└─────────────────────────────────┘
```

---

## Configuration

### Essential Configuration Files

#### 1. `includes/config.php`
Main configuration file containing all API settings and constants.

**Key Constants:**
```php
// Database
const DB_HOST = '127.0.0.1';
const DB_NAME = 'healthcare_db';
const DB_USER = 'root';
const DB_PASS = '';

// HR API
const HR_API_BASE = 'http://26.137.144.53/HR-EMPLOYEE-MANAGEMENT/API';
const HR_API_AUTH_ENDPOINT = '/get_users.php';
const HR_API_JOB_POSTINGS = '/get_job_postings.php';

// Feature Flags
const EXTERNAL_JOBS_ENABLED = true;
const HR_AUTH_ENABLED = true;
const DEBUG_MODE = true;
```

#### 2. Field Mapping Configuration
Maps external API fields to local database fields:

```php
const EXTERNAL_JOBS_FIELD_MAP = [
    'jobID' => 'external_id',
    'job_title' => 'title',
    'job_description' => 'description',
    'department' => 'department',
    'location' => 'location',
    'employment_type' => 'employment_type',
    'date_posted' => 'posted_at',
    'closing_date' => 'closes_at',
    'expected_salary' => 'salary_range',
    'image' => 'image_url'
];
```

---

## Error Handling

### API Connection Errors

**File:** `includes/jobs_integration.php`

```php
// Timeout handling
if (strpos($err, 'Timeout') !== false || strpos($err, 'timeout') !== false) {
    $errorMsg = "API server timeout. The HR API may be unreachable or require VPN/network access.";
}

// DNS resolution errors
elseif (strpos($err, 'resolve') !== false || strpos($err, 'getaddrinfo') !== false) {
    $errorMsg = "Cannot resolve API hostname. Please verify the API URL is correct.";
}

// Connection refused
elseif (strpos($err, 'Connection refused') !== false) {
    $errorMsg = "Connection refused. The API server may be down or blocking connections.";
}
```

### Retry Logic

```php
// File: includes/jobs_integration.php - Lines 96-114

$maxRetries = 2;
for ($attempt = 1; $attempt <= $maxRetries; $attempt++) {
    $apiResponse = fetch_jobs_from_api();
    
    if (isset($apiResponse['status']) && $apiResponse['status'] !== 'error') {
        break; // Success
    }
    
    if ($attempt < $maxRetries) {
        sleep(1 * $attempt); // Exponential backoff
        error_log("HR API attempt {$attempt} failed, retrying...");
    }
}
```

### Fallback Behavior

**When HR API is Offline:**
1. **Authentication** - Falls back to local database only
2. **Job Sync** - Fails silently, displays existing jobs
3. **User Experience** - No disruption, error logged in `error_log`

**When API Returns Unexpected Format:**
- Multiple response format detection
- Falls back to local data
- Logs warnings for debugging

```php
// File: includes/jobs_integration.php - Lines 142-155
if (isset($apiResponse['data']) && is_array($apiResponse['data'])) {
    $externalJobs = $apiResponse['data'];
} elseif (isset($apiResponse['jobs']) && is_array($apiResponse['jobs'])) {
    $externalJobs = $apiResponse['jobs'];
} elseif (isset($apiResponse['job_postings'])) {
    $externalJobs = $apiResponse['job_postings'];
} else {
    // Fallback - use empty array
    $externalJobs = [];
}
```

---

## Key Files Reference

| File | Purpose |
|------|---------|
| `includes/config.php` | All API and database configuration |
| `includes/hr_api.php` | HR API communication functions |
| `includes/jobs_integration.php` | Job sync logic and field mapping |
| `includes/auth.php` | User authentication with HR fallback |
| `api/doctors.php` | Internal API: List doctors |
| `api/book_appointment.php` | Internal API: Create appointment |
| `api/search.php` | Internal API: Search posts/jobs |
| `api/blog.php` | Internal API: Fetch blog posts |
| `api/suggestions.php` | Internal API: Search autocomplete |
| `public/careers.php` | Triggers automatic job sync |

---

## Testing the APIs

### Test HR Authentication
```bash
# Test HR API authentication endpoint
curl -X POST http://26.137.144.53/HR-EMPLOYEE-MANAGEMENT/API/get_users.php \
  -H "Content-Type: application/json" \
  -d '{"user":{"email":"test@example.com","password":"password123"}}'
```

### Test Job Postings API
```bash
# Fetch all job postings
curl -X POST http://26.137.144.53/HR-EMPLOYEE-MANAGEMENT/API/get_job_postings.php \
  -H "Content-Type: application/json" \
  -d '{"search":"","department_id":0,"employment_type_id":0}'
```

### Test Internal APIs
```bash
# List doctors
curl http://localhost/healthcare-system/api/doctors.php

# Search posts
curl "http://localhost/healthcare-system/api/search.php?q=health&type=posts"

# Book appointment
curl -X POST http://localhost/healthcare-system/api/book_appointment.php \
  -d "name=John Doe&age=35&email=john@test.com&phone=123456&doctor_id=DOC001&date=2024-12-15&time=10:00"
```

---

## Debugging Tips

1. **Enable Debug Mode**
   ```php
   const DEBUG_MODE = true; // in includes/config.php
   ```

2. **Check Error Logs**
   - PHP error log: `C:\xampp\apache\logs\error.log`
   - Look for "HR API" or "Job sync" entries

3. **Test API Connectivity**
   ```php
   // Add to test page
   $result = fetch_jobs_from_api();
   var_dump($result);
   ```

4. **Monitor Session Variables**
   ```php
   var_dump($_SESSION['last_job_sync']);
   var_dump($_SESSION['user']);
   ```

---

## Security Considerations

1. **API Credentials** - Stored in `config.php` (should be environment variables in production)
2. **Input Validation** - All API inputs are sanitized and validated
3. **SQL Injection Prevention** - Uses prepared statements everywhere
4. **CSRF Protection** - Session-based authentication
5. **Rate Limiting** - Login attempts are rate-limited
6. **Password Hashing** - All passwords use bcrypt

---

## Future Improvements

1. **Caching** - Implement Redis/Memcached for API responses
2. **Webhooks** - Real-time job updates instead of polling
3. **API Versioning** - Version internal APIs for backward compatibility
4. **GraphQL** - Consider GraphQL for more efficient data fetching
5. **Queue System** - Background job processing for heavy sync operations

---

*Last Updated: December 4, 2024*
*Version: 1.0*
