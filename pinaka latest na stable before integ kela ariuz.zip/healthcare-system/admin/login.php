<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/init.php';

$error = null;
$locked = false;
$lockoutRemaining = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    try {
        // Check rate limiting first
        $ip = get_client_ip();
        if (is_rate_limited($ip)) {
            $remaining = get_lockout_remaining($ip);
            $error = 'Too many login attempts. Please try again in ' . ceil($remaining / 60) . ' minutes.';
            $locked = true;
            $lockoutRemaining = $remaining;
        } else {
            // Check if this is an email address (HR user)
            $isEmail = filter_var($username, FILTER_VALIDATE_EMAIL) !== false;
            $shouldRedirectExternally = false;

            // If it's an email and HR is enabled, check if this user should redirect externally
            if ($isEmail && HR_AUTH_ENABLED && defined('HR_EXTERNAL_REDIRECT_USERS')) {
                $shouldRedirectExternally = in_array(strtolower($username), array_map('strtolower', HR_EXTERNAL_REDIRECT_USERS), true);
            }

            // Try authentication (handles both local and HR users)
            // The attempt_login() function will:
            // 1. Check local database first
            // 2. If not found locally and HR is enabled, authenticate via HR API
            // 3. Sync HR users to local database and create local session
            $result = attempt_login($username, $password);

            if ($result['success']) {
                // Clear any output buffer before redirect
                if (ob_get_level()) {
                    ob_end_clean();
                }

                // Get the current user info to determine routing
                $currentUser = current_user();
                $userRole = strtolower($currentUser['role'] ?? 'staff');
                $userEmail = $currentUser['email'] ?? '';

                // Determine redirect URL based on routing rules
                $redirectUrl = null;

                // Priority 1: Check if this is an HR external redirect user
                if ($shouldRedirectExternally && $isEmail) {
                    if (defined('HR_DASHBOARD_URL') && HR_DASHBOARD_URL) {
                        $redirectUrl = HR_DASHBOARD_URL;
                    } else {
                        $redirectUrl = 'http://26.137.144.53/HR-EMPLOYEE-MANAGEMENT/Manager_Dashboard.php';
                    }
                }

                // Priority 2: Check email domain routing
                if (!$redirectUrl && defined('DOMAIN_ROUTING')) {
                    foreach (DOMAIN_ROUTING as $domain => $url) {
                        if (stripos($userEmail, $domain) !== false) {
                            $redirectUrl = $url;
                            break;
                        }
                    }
                }

                // Priority 3: Check role-based routing
                if (!$redirectUrl && defined('ROLE_ROUTING')) {
                    $roleRouting = ROLE_ROUTING;
                    if (isset($roleRouting[$userRole]) && $roleRouting[$userRole] !== null) {
                        $redirectUrl = $roleRouting[$userRole];
                    }
                }

                // Default: Healthcare admin dashboard
                if (!$redirectUrl) {
                    $redirectUrl = url('/admin/dashboard.php');
                }

                // Perform redirect
                header('Location: ' . $redirectUrl, true, 302);
                exit;
            }

            $error = $result['error'] ?? 'Invalid credentials. Please try again.';
            $locked = $result['locked'] ?? false;
            $lockoutRemaining = $result['remaining'] ?? 0;
        }
    } catch (Throwable $e) {
        error_log('Login error: ' . $e->getMessage());
        $error = 'An error occurred during login. Please try again.';
    }
}

if (current_user()) {
    redirect('/admin/dashboard.php');
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login — <?= e(APP_NAME); ?></title>

    <!-- Weh Design System -->
    <link rel="stylesheet" href="<?= url('/public/css/weh/global.css'); ?>">
    <link rel="stylesheet" href="<?= url('/public/css/weh/components.css'); ?>">

    <style>
        body {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-color: var(--color-background);
            padding: 1rem;
        }

        .login-card {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;

            background-color: var(--color-surface);
            width: 100%;
            max-width: 400px;

            padding: 2rem;

            border: 2px solid var(--color-border);
            border-radius: var(--radius-outer);
            box-shadow: var(--shadow-surface);
        }

        .login-header {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 2rem;
            text-align: center;
        }

        .login-header img {
            height: 80px;
            width: auto;
            margin-bottom: 1rem;
            border-radius: var(--radius-inner);
        }

        .login-form {
            width: 100%;
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .alert {
            width: 100%;
            padding: 1rem;
            margin-bottom: 1rem;
            border-radius: var(--radius-inner);
            font-size: 0.9rem;
            text-align: center;
        }

        .alert-danger {
            background-color: var(--color-error-light);
            color: var(--color-error);
            border: 1px solid var(--color-error);
        }
    </style>
</head>

<body>

    <section class="login-card">
        <div class="login-header">
            <img src="<?= asset('images/logo.jpg'); ?>" alt="<?= e(APP_NAME); ?>"
                style="height: 60px; margin-bottom: 1rem; border-radius: 8px; mix-blend-mode: screen;">
            <h1>Admin Login</h1>
            <p style="color: var(--color-text-muted);">Sign in to manage the system</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger">
                <?= e($error); ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="login-form">
            <div class="component__textfield --no-icon">
                <input type="text" name="username" id="username" placeholder="Email or Username" required autofocus
                    value="<?= e($_POST['username'] ?? ''); ?>">
            </div>

            <div class="component__textfield --no-icon">
                <input type="password" name="password" id="password" placeholder="Password" required>
            </div>

            <button class="component__button --primary" type="submit" style="width: 100%; justify-content: center;">
                <span>Login</span>
            </button>
        </form>

        <div style="margin-top: 1.5rem; text-align: center;">
            <a href="<?= url('/public/index.php'); ?>"
                style="color: var(--color-primary); text-decoration: none; font-weight: bold;">
                &larr; Back to Home
            </a>
        </div>
    </section>

</body>

</html>