<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/init.php';
require_admin_or_staff();

$db = get_db();

$totals = [
    'total_posts' => (int) $db->query('SELECT COUNT(*) FROM posts')->fetchColumn(),
    'published_posts' => (int) $db->query("SELECT COUNT(*) FROM posts WHERE status = 'published'")->fetchColumn(),
    'draft_posts' => (int) $db->query("SELECT COUNT(*) FROM posts WHERE status = 'draft'")->fetchColumn(),
];

$recentPostsStmt = $db->query(
    'SELECT id, title, status, updated_at, published_at 
     FROM posts 
     ORDER BY updated_at DESC 
     LIMIT 6'
);
$recentPosts = $recentPostsStmt->fetchAll();

$pageTitle = 'Dashboard';
$activePage = 'dashboard';
include __DIR__ . '/partials/header.php';
?>

<style>
    .dashboard-stats {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 1.5rem;
        margin-bottom: 2rem;
    }

    .dashboard-content {
        display: grid;
        grid-template-columns: 2fr 1fr;
        gap: 1.5rem;
    }

    @media (max-width: 992px) {
        .dashboard-content {
            grid-template-columns: 1fr;
        }
    }

    .stat-value {
        font-size: 3rem;
        font-weight: bold;
        margin: 0.5rem 0;
        text-align: center;
    }

    .stat-label {
        text-align: center;
        color: var(--color-text-muted);
        padding-bottom: 1rem;
    }
</style>

<div class="dashboard-stats">
    <!-- Total Posts -->
    <div class="component__card">
        <div class="component__card-header">
            <i class="bi bi-journal-text" style="font-size: 2rem; color: var(--color-primary);"></i>
            <h1>Total Posts</h1>
        </div>
        <div class="stat-value"><?= e((string) $totals['total_posts']); ?></div>
        <div class="stat-label">All stories in the CMS</div>
    </div>

    <!-- Published -->
    <div class="component__card --success">
        <div class="component__card-header">
            <i class="bi bi-check-circle" style="font-size: 2rem; color: var(--color-success);"></i>
            <h1>Published</h1>
        </div>
        <div class="stat-value" style="color: var(--color-success);"><?= e((string) $totals['published_posts']); ?>
        </div>
        <div class="stat-label">Live on the site</div>
    </div>

    <!-- Drafts -->
    <div class="component__card --warning">
        <div class="component__card-header">
            <i class="bi bi-pencil-square" style="font-size: 2rem; color: var(--color-warning);"></i>
            <h1>Drafts</h1>
        </div>
        <div class="stat-value" style="color: var(--color-warning);"><?= e((string) $totals['draft_posts']); ?></div>
        <div class="stat-label">Waiting for review</div>
    </div>
</div>

<div class="dashboard-content">
    <!-- Recent Posts -->
    <div>
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
            <h3>Recent Posts</h3>
            <a href="<?= url('/admin/posts.php'); ?>" class="component__button --secondary"
                style="height: 2.5rem; font-size: 0.9rem; text-decoration: none;">
                <span>Manage Posts</span>
            </a>
        </div>

        <div class="component__table">
            <table>
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Status</th>
                        <th>Updated</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($recentPosts)): ?>
                        <tr class="--empty">
                            <td colspan="4">No posts yet. Create your first story.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($recentPosts as $post): ?>
                            <tr>
                                <td><?= e($post['title']); ?></td>
                                <td>
                                    <?php
                                    $statusColors = [
                                        'published' => 'var(--color-success)',
                                        'draft' => 'var(--color-warning)'
                                    ];
                                    $statusColor = $statusColors[$post['status']] ?? 'var(--color-text)';
                                    ?>
                                    <span style="color: <?= $statusColor; ?>; font-weight: bold;">
                                        <?= e(ucfirst($post['status'])); ?>
                                    </span>
                                </td>
                                <td><?= e(date('M d, Y', strtotime($post['updated_at']))); ?></td>
                                <td>
                                    <div class="component__table-action">
                                        <a href="<?= url('/admin/posts.php?edit=' . urlencode($post['id'])); ?>" title="Edit">
                                            <div>
                                                <i class="bi bi-pencil" style="color: var(--color-primary);"></i>
                                            </div>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Quick Actions -->
    <div>
        <h3 style="margin-bottom: 1rem;">Quick Actions</h3>
        <div class="component__card">
            <div style="padding: 1.5rem; width: 100%; display: flex; flex-direction: column; gap: 1rem;">
                <a href="<?= url('/admin/posts.php'); ?>" class="component__button --primary"
                    style="text-decoration: none; justify-content: center;">
                    <i class="bi bi-plus-lg"></i>
                    <span>Create New Post</span>
                </a>

                <a href="<?= url('/public/blog.php'); ?>" target="_blank" class="component__button --secondary"
                    style="text-decoration: none; justify-content: center;">
                    <i class="bi bi-eye"></i>
                    <span>Preview Blog</span>
                </a>

                <hr style="border-top: 2px solid var(--color-border); width: 100%;">

                <div>
                    <strong style="display: block; margin-bottom: 0.5rem;">Publishing Tips</strong>
                    <ul style="padding-left: 1.2rem; margin: 0; color: var(--color-text-muted); font-size: 0.9rem;">
                        <li>Keep slugs short and descriptive.</li>
                        <li>Use the draft state while reviewing.</li>
                        <li>Published posts appear instantly.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/partials/footer.php'; ?>