-- Remove accidentally added tables from healthcare_db
-- These tables don't belong in the healthcare content management system

-- Disable foreign key checks to avoid constraint errors
SET FOREIGN_KEY_CHECKS = 0;

-- Drop the accidentally added tables
DROP TABLE IF EXISTS batches;
DROP TABLE IF EXISTS company;
DROP TABLE IF EXISTS email;
DROP TABLE IF EXISTS employee;
DROP TABLE IF EXISTS inventory;
DROP TABLE IF EXISTS messages;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS notification_state;
DROP TABLE IF EXISTS otpverify;
DROP TABLE IF EXISTS pending_orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS requests;
DROP TABLE IF EXISTS suppliers;
DROP TABLE IF EXISTS units;
DROP TABLE IF EXISTS userinfo;
DROP TABLE IF EXISTS userroles;

-- Re-enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1;

-- Verify remaining tables (should only show the 7 correct tables)
SHOW TABLES;
