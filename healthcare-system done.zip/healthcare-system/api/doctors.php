<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/init.php';

header('Content-Type: application/json');

try {
    $db = get_db();
    $stmt = $db->query('SELECT id, name, specialty FROM doctors ORDER BY name');
    echo json_encode($stmt->fetchAll());
} catch (Throwable $th) {
    http_response_code(500);
    echo json_encode(['error' => 'Unable to load doctors']);
}


