<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/init.php';
require_once __DIR__ . '/../includes/hr_api.php';

header('Content-Type: application/json');

// Support both GET and POST parameters
// POST is preferred for security (credentials in URL is not secure)
$email = $_POST['email'] ?? $_GET['email'] ?? '';
$password = $_POST['password'] ?? $_GET['password'] ?? '';
$subRole = $_POST['sub_role'] ?? $_GET['sub_role'] ?? '';

// Validate required parameters
if (empty($email) || empty($password)) {
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => 'Email and password are required'
    ]);
    exit;
}

// Check if HR authentication is enabled
if (!HR_AUTH_ENABLED) {
    http_response_code(503);
    echo json_encode([
        'status' => 'error',
        'message' => 'HR authentication is disabled'
    ]);
    exit;
}

// Prepare the payload
$payload = [
    'user' => [
        'email' => $email,
        'password' => $password,
        'sub_role' => $subRole,
    ],
];

// Call the HR API using the existing integration function
$response = call_hr_api(HR_API_AUTH_ENDPOINT, $payload);

if (!$response['success']) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => $response['error'] ?? 'Failed to connect to HR system'
    ]);
    exit;
}

// Return the HR API response
// The response data is already parsed JSON from call_hr_api()
http_response_code(200);
echo json_encode($response['data']);

